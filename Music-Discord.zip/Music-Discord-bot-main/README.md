# Music-Discord-bot
Discord music bot that actually works, just put your personal bot token and set your prefix in config.json and it will be ready to go!

Commands that you can use: 

{prefix}play (your youtube link here); 

{prefix}skip;

{prefix}stop;
